#! /bin/bash

set -e

docker pull cammey20/sample-python-flask-app

docker run -d -p 5000:5000 cammey20/sample-python-flask-app