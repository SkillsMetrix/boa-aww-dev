#! /bin/bash

set -e

echo "hello"